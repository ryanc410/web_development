<?php
$coder_current_path = plugin_dir_path( __FILE__ );
require_once trailingslashit( $coder_current_path ) . '/hooks/add-setting-controls.php';