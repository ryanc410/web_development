<?php
/*Service Section*/
$bizlight_customizer_service_setting_file_path = bizlight_file_directory('inc/customizer/home-options/service/service-panel.php');
require $bizlight_customizer_service_setting_file_path;

/*About Section*/
$bizlight_customizer_about_setting_file_path = bizlight_file_directory('inc/customizer/home-options/about/about-panel.php');
require $bizlight_customizer_about_setting_file_path;

/*Home featured Section*/
$bizlight_customizer_home_featured_file_path = bizlight_file_directory('inc/customizer/home-options/home-featured.php');
require $bizlight_customizer_home_featured_file_path;

/*Home blog Section*/
$bizlight_customizer_home_brand_file_path = bizlight_file_directory('inc/customizer/home-options/home-brand.php');
require $bizlight_customizer_home_brand_file_path;


/*Home blog Section*/
$bizlight_customizer_home_blog_file_path = bizlight_file_directory('inc/customizer/home-options/home-blog.php');
require $bizlight_customizer_home_blog_file_path;

/*Home testimonials Section*/
$bizlight_customizer_home_testimonial_panel_file_path = bizlight_file_directory('inc/customizer/home-options/testimonial/testimonial-panel.php');
require $bizlight_customizer_home_testimonial_panel_file_path;